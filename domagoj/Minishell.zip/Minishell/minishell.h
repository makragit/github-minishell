/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dbogovic <dbogovic@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/02 20:00:58 by domagoj           #+#    #+#             */
/*   Updated: 2025/01/01 21:10:48 by dbogovic         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINISHELL_H
# define MINISHELL_H

# include "libft-delete/libft.h"
# include <unistd.h>
# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <ctype.h>

extern int	last_executed_cmd;
typedef enum token_type
{
	CMD_TOKEN,
	ARG_TOKEN,
	APPEND,
	HEREDOC,
	INPUT,
	REDIRECTION,
	OUTPUT,
	WORD,
	PIPE_TOKEN,
	ENV_VAR_TOKEN,
	S_QUOTED_STR_TOKEN,
	D_QUOTED_STR_TOKEN,
}	token_type;

typedef struct t_token
{
	char			*value;
	token_type		type;
	struct t_token	*next;
	struct t_token	*previous;
}	t_token;

typedef struct t_cmd_table
{
	int					index;
	char				*cmd;
	char				**args;
	char				*input_redir;
	char				*output_redir;
	char				*append_redir;
	char				*heredoc_delim;
	struct t_cmd_table	*next;
}	t_cmd_table;

t_token		*cut_token(t_token *token);
t_cmd_table	*parse(const char *input);
t_token		*tokenize(char *input_string);
size_t		token_len(char *str);
void		token_categorisation(t_token *tokens);
int			make_token_entry(t_token **tokens, char *str_token);
t_cmd_table	*table_init(size_t of_size);
void		token_distribution(t_cmd_table *table, t_token *token);
int			arr_create(t_cmd_table *table, t_token *token);
int			expander(t_cmd_table **table);
int			expand_exit_status(char **str);
int			expand_env(char **arg);
int			is_whitespace(char c);
int			skip_whitespace(char **str);
void		free_table(t_cmd_table *table);
void		cmd_print(t_cmd_table *table);
void		fully_free(t_token *lst);
char		*ft_strexpel(char *haystack, const char *needle);
int			*find_indexes(char *haystack, char *needle);
int			ft_str_insert(char **src, char *insert, size_t place);
int			ft_trim_quotes(char **str);
void		cmd_print(t_cmd_table *table);
t_token		*reverse_lst(t_token *lst);
void		free_lst(t_token *lst);
void		add_previous(t_token *lst);
int			input_check(const char *input);
#endif
