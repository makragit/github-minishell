Notes

*its probably best we merge officialy by friday/saturday - because I MIGHT do some small restructuring in tese few days

-You have to implement that if !input (user just pressed enter), you ask for input again!

Functions you will use from my part:

----------t_cmd_table	*parse(const char *input);----------

->RETURNS -succes - table structure for future use
	 	  -FAILURE - NULL
*in both cases, input string is UNTOUCHED!


------------void	free_table(t_cmd_table *table);---------
->void return function that will free the table after use!



-----------void cmd_print(t_cmd_table *table);------------
->void function that will print out data captured from input for you to check out!





You should destroy folder "libft-delete"
I kept my makefile as simple as possible, so rest should be easy to merger
folder structure should be same (otherwise you would have to change #include"../minishell.h" stuff)
minishell.h should be merged ofcourse, Makefile and main.c pretty much deleted

In your testing you should know following!

- do not deal with HEREDOC, I will do it tomorrow or friday
- if you put stuff that isnt valid, some stuff CAN return leaks!
- any valid command shouldnt leak, please notify me of example if you find!
